﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.essay_browse_button = new System.Windows.Forms.Button();
            this.uploadessay_textbox = new System.Windows.Forms.TextBox();
            this.go_button = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wordfreq_dataGridView = new System.Windows.Forms.DataGridView();
            this.Word = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Frequency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.title_TextBox = new System.Windows.Forms.TextBox();
            this.author_TextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CBX_Titles = new System.Windows.Forms.ComboBox();
            this.CBX_Authors = new System.Windows.Forms.ComboBox();
            this.connect_button = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.upload_check = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wordfreq_dataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // essay_browse_button
            // 
            this.essay_browse_button.Location = new System.Drawing.Point(344, 31);
            this.essay_browse_button.Name = "essay_browse_button";
            this.essay_browse_button.Size = new System.Drawing.Size(75, 23);
            this.essay_browse_button.TabIndex = 0;
            this.essay_browse_button.Text = "Browse";
            this.essay_browse_button.UseVisualStyleBackColor = true;
            this.essay_browse_button.Click += new System.EventHandler(this.essay_browse_button_Click);
            // 
            // uploadessay_textbox
            // 
            this.uploadessay_textbox.Location = new System.Drawing.Point(26, 33);
            this.uploadessay_textbox.Name = "uploadessay_textbox";
            this.uploadessay_textbox.Size = new System.Drawing.Size(312, 20);
            this.uploadessay_textbox.TabIndex = 1;
            // 
            // go_button
            // 
            this.go_button.Location = new System.Drawing.Point(276, 74);
            this.go_button.Name = "go_button";
            this.go_button.Size = new System.Drawing.Size(143, 59);
            this.go_button.TabIndex = 2;
            this.go_button.Text = "Read";
            this.go_button.UseVisualStyleBackColor = true;
            this.go_button.Click += new System.EventHandler(this.go_button_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Data,
            this.Value});
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(745, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(204, 304);
            this.dataGridView1.TabIndex = 3;
            // 
            // Data
            // 
            this.Data.HeaderText = "Data";
            this.Data.Name = "Data";
            // 
            // Value
            // 
            this.Value.HeaderText = "Value";
            this.Value.Name = "Value";
            // 
            // wordfreq_dataGridView
            // 
            this.wordfreq_dataGridView.AllowUserToAddRows = false;
            this.wordfreq_dataGridView.AllowUserToDeleteRows = false;
            this.wordfreq_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.wordfreq_dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Word,
            this.Frequency});
            this.wordfreq_dataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.wordfreq_dataGridView.Location = new System.Drawing.Point(514, 64);
            this.wordfreq_dataGridView.Name = "wordfreq_dataGridView";
            this.wordfreq_dataGridView.RowHeadersVisible = false;
            this.wordfreq_dataGridView.Size = new System.Drawing.Size(205, 304);
            this.wordfreq_dataGridView.TabIndex = 4;
            // 
            // Word
            // 
            this.Word.HeaderText = "Word";
            this.Word.Name = "Word";
            // 
            // Frequency
            // 
            this.Frequency.HeaderText = "Frequency";
            this.Frequency.Name = "Frequency";
            // 
            // title_TextBox
            // 
            this.title_TextBox.Location = new System.Drawing.Point(85, 124);
            this.title_TextBox.Name = "title_TextBox";
            this.title_TextBox.Size = new System.Drawing.Size(175, 20);
            this.title_TextBox.TabIndex = 5;
            // 
            // author_TextBox
            // 
            this.author_TextBox.Location = new System.Drawing.Point(85, 85);
            this.author_TextBox.Name = "author_TextBox";
            this.author_TextBox.Size = new System.Drawing.Size(175, 20);
            this.author_TextBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Title:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Author:";
            // 
            // CBX_Titles
            // 
            this.CBX_Titles.FormattingEnabled = true;
            this.CBX_Titles.Location = new System.Drawing.Point(63, 65);
            this.CBX_Titles.Name = "CBX_Titles";
            this.CBX_Titles.Size = new System.Drawing.Size(197, 21);
            this.CBX_Titles.TabIndex = 9;
            this.CBX_Titles.SelectedIndexChanged += new System.EventHandler(this.CBX_Titles_SelectedIndexChanged);
            // 
            // CBX_Authors
            // 
            this.CBX_Authors.FormattingEnabled = true;
            this.CBX_Authors.Location = new System.Drawing.Point(63, 28);
            this.CBX_Authors.Name = "CBX_Authors";
            this.CBX_Authors.Size = new System.Drawing.Size(197, 21);
            this.CBX_Authors.TabIndex = 10;
            this.CBX_Authors.SelectedIndexChanged += new System.EventHandler(this.CBX_Authors_SelectedIndexChanged);
            // 
            // connect_button
            // 
            this.connect_button.Location = new System.Drawing.Point(276, 33);
            this.connect_button.Name = "connect_button";
            this.connect_button.Size = new System.Drawing.Size(143, 44);
            this.connect_button.TabIndex = 11;
            this.connect_button.Text = "Connect";
            this.connect_button.UseVisualStyleBackColor = true;
            this.connect_button.Click += new System.EventHandler(this.connectToMySQL);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(43, 13);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(906, 23);
            this.progressBar1.TabIndex = 13;
            // 
            // upload_check
            // 
            this.upload_check.AutoSize = true;
            this.upload_check.Location = new System.Drawing.Point(294, 143);
            this.upload_check.Name = "upload_check";
            this.upload_check.Size = new System.Drawing.Size(110, 17);
            this.upload_check.TabIndex = 14;
            this.upload_check.Text = "Upload on Read?";
            this.upload_check.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Author:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Title:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox1.Controls.Add(this.upload_check);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.author_TextBox);
            this.groupBox1.Controls.Add(this.title_TextBox);
            this.groupBox1.Controls.Add(this.go_button);
            this.groupBox1.Controls.Add(this.uploadessay_textbox);
            this.groupBox1.Controls.Add(this.essay_browse_button);
            this.groupBox1.Location = new System.Drawing.Point(43, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(442, 172);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upload an Essay";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.connect_button);
            this.groupBox2.Controls.Add(this.CBX_Authors);
            this.groupBox2.Controls.Add(this.CBX_Titles);
            this.groupBox2.Location = new System.Drawing.Point(43, 263);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(442, 105);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Database";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 405);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.wordfreq_dataGridView);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wordfreq_dataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button essay_browse_button;
        private System.Windows.Forms.TextBox uploadessay_textbox;
        private System.Windows.Forms.Button go_button;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data;
        private System.Windows.Forms.DataGridViewTextBoxColumn Value;
        private System.Windows.Forms.DataGridView wordfreq_dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Word;
        private System.Windows.Forms.DataGridViewTextBoxColumn Frequency;
        private System.Windows.Forms.TextBox title_TextBox;
        private System.Windows.Forms.TextBox author_TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox CBX_Titles;
        private System.Windows.Forms.ComboBox CBX_Authors;
        private System.Windows.Forms.Button connect_button;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.CheckBox upload_check;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

