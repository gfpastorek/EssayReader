﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Net;
using System.Web;
using System.IO;

namespace WindowsFormsApplication1
{


    public partial class Form1 : Form
    {
        essay newessay;
        
        public Form1()
        {
            InitializeComponent();
        }

        //opens the open file dialog and saves the path
        private void essay_browse_button_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            
            ofd.ShowDialog();

            if (ofd.FileName != null)
                uploadessay_textbox.Text = ofd.FileName;
        }

        //event when the user clicks 'Read'
        //reads the essay and records the statistics, writes them to the datagrids
        //if 'Upload to Database?' is checked, send the data to the remote MySQL database 
        private void go_button_Click(object sender, EventArgs e)
        {
            //open essay
            newessay = new essay(uploadessay_textbox.Text);

            //read essay, get data
            if(!(newessay.read_essay()))
                return;

            //add data to datagrid
            dataGridView1.Rows.Clear();
            dataGridView1.Rows.Add("Sentence Count", newessay.sentencecount);
            dataGridView1.Rows.Add("Word Count", newessay.wordcount);
            dataGridView1.Rows.Add("Character Count", newessay.charactercount);
            dataGridView1.Rows.Add("Comma Count", newessay.commacount);
            dataGridView1.Rows.Add("Semicolon Count", newessay.semicoloncount);
            dataGridView1.Rows.Add("Hyphen Count", newessay.hyphencount);
            dataGridView1.Rows.Add("Words per Sentence", newessay.wordcount / newessay.sentencecount);
            dataGridView1.Rows.Add("Characters per Word", newessay.charactercount / newessay.wordcount);

            //add word frequencies to datagrid
            foreach (DictionaryEntry pair in newessay.wordfreq)
            {
                wordfreq_dataGridView.Rows.Add(pair.Key, pair.Value);
            }

            //if true, add data to remote MySQL database
            if (upload_check.Checked == true)
            {
                newessay.authorID = getAuthorID(author_TextBox.Text);   //gets authorID, if author not found, add a new author
                uploadEssayToMySQL(newessay);
            }

            newessay.clear();
        }

        //uploads all essay data to remote MySQL database
        private void uploadEssayToMySQL(essay essay)
        {
            //add an essay tuple
            string sqlQuery = "INSERT INTO essay VALUES(" +
                              "DEFAULT, " +
                              "'" + title_TextBox.Text + "', " +
                              newessay.authorID + ", " +
                              newessay.sentencecount + ", " +
                              newessay.hyphencount + ", " +
                              newessay.wordcount + ", " +
                              newessay.charactercount + ", " +
                              newessay.commacount + ", " +
                              newessay.sentencecount + ")";

            sendModifyQuery(sqlQuery);

            newessay.essayID = getEssayID();    //get essayID of tuple we just added

            //add each word frequency
            progressBar1.Maximum = newessay.wordfreq.Count;
            foreach (DictionaryEntry pair in newessay.wordfreq)
            {
                sqlQuery = "INSERT INTO words VALUES(" +
                           newessay.essayID + ", " +
                           "'" + pair.Key.ToString() + "', " +
                           pair.Value + ")";
                
                sendModifyQuery(sqlQuery);
                ++progressBar1.Value;
            }
            progressBar1.Value = 0;
        }

        //sends a modification query and does not return result (i.e INSERT, UPDATE, DELETE,...)
        private void sendModifyQuery(string sqlQuery)
        {
            string url = "http://web.engr.illinois.edu/~pastork2/modify.php?sql=" + sqlQuery;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            response.Close();
        }
        
        //sends a query and returns the result echo'd from the page
        //PHP returns the results in JSON format
        private string sendReadQuery(string sqlQuery)
        {
            string url = "http://web.engr.illinois.edu/~pastork2/query.php?sql=" + HttpUtility.UrlEncode(sqlQuery);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader result = new StreamReader(response.GetResponseStream());
            string resultstring = result.ReadToEnd();
            response.Close();

            return resultstring;
        }

        //gets the authorID of the author name entered. If it is not an exist entry, create a new one
        private int getAuthorID(string name)
        {
            int ID;
            string sqlQuery = "SELECT authorID FROM author WHERE name ='" + name + "'";
            string resultstring = sendReadQuery(sqlQuery);
            if (resultstring.Length < 4)
                ID = addAuthorToMySQL(name);
            else
            {
                resultstring = resultstring.Replace("{\"result\":[{\"authorID\":\"", "").Replace("\"}]}", "");
                ID = Convert.ToInt32(resultstring);
            }
           return ID;
        }

        //adds a new author to the database
        private int addAuthorToMySQL(string name)
        {
            string insertQuery = "INSERT INTO author VALUES(DEFAULT, '" + name + "')";
            sendModifyQuery(insertQuery);

            string sqlQuery = "select max(authorID) from author";
            string resultstring = sendReadQuery(sqlQuery);
            resultstring = resultstring.Replace("{\"result\":[{\"max(authorID)\":\"", "").Replace("\"}]}", "");
            int ID = Convert.ToInt32(resultstring);

            return ID;
        }

        //gets the essayID of the last entry created
        private int getEssayID()
        {
            string sqlQuery = "select max(essayID) from essay";
            string resultstring = sendReadQuery(sqlQuery);
            resultstring = resultstring.Replace("{\"result\":[{\"max(essayID)\":\"", "").Replace("\"}]}", "");
            int ID = Convert.ToInt32(resultstring);
            return ID;
        }

        private void connectToMySQL(object sender, EventArgs e)
        {
            connectToMySQL();
        }

        //loads the list of authors from the database to the authors combobox
        private bool connectToMySQL()
        {
            try
            {
                string sqlQuery = "select name from author";
                string resultstring = sendReadQuery(sqlQuery);
                
                addAuthors(resultstring);   

                return true;
            }
            catch
            {
                return false;
            }
           
        }

        //add list of authors to the combobox
        private void addAuthors(string resultstring)
        {
            //decode the resultstring
            resultstring = resultstring.Replace("{\"name\":\"", "|").Replace("\"},", "");
            string[] authorsList = resultstring.Split('|');
            authorsList[authorsList.Count() - 1] = authorsList[authorsList.Count() - 1].Replace("\"}]}", "");

            //add authors to combobox
            for (int i = 1; i < authorsList.Count(); ++i)
                CBX_Authors.Items.Add(authorsList[i]);
        }

        //adds list of selected author's essays to the titles combobox
        private void CBX_Authors_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                CBX_Titles.Items.Clear();

                string sqlQuery = "SELECT title FROM essay, author " +
                                  "WHERE essay.authorID = author.authorID AND author.name = '" + CBX_Authors.Text + "'";
                
                string resultstring = sendReadQuery(sqlQuery);
                
                resultstring = resultstring.Replace("{\"title\":\"", "|").Replace("\"},", "");
                string[] titleList = resultstring.Split('|');
                titleList[titleList.Count() - 1] = titleList[titleList.Count() - 1].Replace("\"}]}", "");

                for (int i = 1; i < titleList.Count(); ++i)
                    CBX_Titles.Items.Add(titleList[i]);

                author_TextBox.Text = CBX_Authors.Text;
            }
            catch { }
        }

        //add essay data to the datagrids when an essay is selected from the combobox
        private void CBX_Titles_SelectedIndexChanged(object sender, EventArgs e)
        {
            string title = CBX_Titles.Text;
            
            string sqlQuery = "SELECT sentence_count, hyphen_count, word_count, character_count, comma_count, semicolon_count FROM essay WHERE title = '" + title + "'";
            string resultstring = sendReadQuery(sqlQuery);
            decodeEssayData(resultstring);
             
            sqlQuery = "SELECT word, frequency FROM words WHERE essayID = (SELECT essayID FROM essay WHERE title = '" + title + "')";
            resultstring = sendReadQuery(sqlQuery);
            decodeWordFreqData(resultstring);

        }

        //reads the result string from the query and updates the essay statistics datagrid accordingly
        private void decodeEssayData(string resultstring)
        {
            resultstring = resultstring.Replace(",", "|").Replace("\"", "");
            string[] essaydata = resultstring.Split('|');

            essaydata[0] = essaydata[0].Replace("{result:[{", "");
            essaydata[essaydata.Count()-1] = essaydata[essaydata.Count() - 1].Replace("}]}", "");

            dataGridView1.Rows.Clear();

            int ind;
            string data;
            int value;
            int cc = 0;
            int wc = 0;
            int sc = 0;

            for (int i = 0; i < essaydata.Count(); i++)
            {
                ind = essaydata[i].IndexOf(":");
                data = essaydata[i].Substring(0, ind).Replace("_", " ");
                value = Convert.ToInt32(essaydata[i].Substring(ind+1));
                dataGridView1.Rows.Add(data, value);

                //gets the indexes of certain rows used for later calculations
                if (data == "sentence count")
                    sc = i;
                else if (data == "word count")
                    wc = i;
                else if (data == "character count")
                    cc = i;
                
            }
            //calculates words per sentence
            double calc = Convert.ToDouble(dataGridView1.Rows[wc].Cells[1].Value) / Convert.ToDouble(dataGridView1.Rows[sc].Cells[1].Value);
            dataGridView1.Rows.Add("words per sentence", calc);

            //calculates characters per word
            calc = Convert.ToDouble(dataGridView1.Rows[cc].Cells[1].Value) / Convert.ToDouble(dataGridView1.Rows[wc].Cells[1].Value);
            dataGridView1.Rows.Add("characters per word", calc);

        }

        //reads the result string from the query and updates the word frequency datagrid accordingly
        private void decodeWordFreqData(string resultstring)
        {
            resultstring = resultstring.Replace("},{", "|").Replace("\"", "");
            string[] worddata = resultstring.Split('|');

            //gets an array of worddata tuples
            worddata[0] = worddata[0].Replace("{result:[{", "");
            worddata[worddata.Count() - 1] = worddata[worddata.Count() - 1].Replace("}]}", "");

            wordfreq_dataGridView.Rows.Clear();

            string word;
            int frequency;

            //add each tuple from 'words' relation
            for (int i = 0; i < worddata.Count(); i++)
            {
                string[] attributes = worddata[i].Split(',');  //splits each tuple into attributes
                if (attributes.Length > 2) { attributes[1] = attributes[attributes.Length - 1]; }   //catches errors where it returns more than two attributes
                word = attributes[0].Substring(attributes[0].IndexOf(":") + 1);
                frequency = Convert.ToInt32(attributes[1].Substring(attributes[1].IndexOf(":") + 1));

                wordfreq_dataGridView.Rows.Add(word, frequency);
            }

        }

        
    }
}
