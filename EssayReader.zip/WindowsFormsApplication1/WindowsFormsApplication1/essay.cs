﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace WindowsFormsApplication1
{
    public class essay
    {
        public int essayID;
        public int authorID;

        //essay data, to be exported to database
        public List<string> word_list;
        public Hashtable wordfreq = new Hashtable();
        public int wordcount = 0;
        public int sentencecount = 0;
        public long charactercount = 0;
        public int commacount = 0;
        public int semicoloncount = 0;
        public int hyphencount = 0;

        //collection of abbreviated titles that occur before proper nouns
        private string[] abrv_titles = new string[9] { "mr.", "mrs.", "ms.", "mr.", "prof.", "dr.", "gen.", "sen.", "st."};

        //constructor, reads essay and creates the word_list linked list
        public essay(string filename)
        {
            try
            {
                string[] essay_array = System.IO.File.ReadAllText(filename).Replace("\n", " ").Replace("\t", " ").Replace("\r", " ").Split(' ', '—');
                word_list = essay_array.Cast<string>().ToList();
            }
            catch { }
        }

        //clears all public variables
        public void clear()
        {
            word_list.Clear();
            wordfreq.Clear();
            wordcount = 0;
            sentencecount = 0;
            charactercount = 0;
            commacount = 0;
            semicoloncount = 0;
            hyphencount = 0;
        }

        //reads the essay, finds the essay data (word frequencies and other stats)
        public bool read_essay()
        {
            //return error if there are no words in the essay (returns false here if the filepath was invalid)
            if (word_list == null)
                return false;

            wordcount = word_list.Count;

            //loops through each word in the essay
            for(int i = 0; i < word_list.Count; i++)
            {
               string word = word_list[i];
               
               //discount wordcount for each empty string that was counted as a word
               if (word == ""){
                   --wordcount;
                   continue;
               }
               
               charactercount += word.Length;

               //updates the word frequency hashtable
               countWordFrequency(word);

               //checks each word for punctuation, counts punctuation statistics and determines if we are at the end of the sentence
               checkPunctuation(word, i);

            }

            return true;

        }

        private void countWordFrequency(string word)
        {
            //omits punctuation from the word
            string lastchar = word.Substring(word.Length - 1);
            if ((lastchar == ".") || (lastchar == "?") || (lastchar == "!") || (lastchar == ",") || 
                (lastchar == ";") || (lastchar == ":") || (lastchar == "\"") )
                word = word.Substring(0, word.Length - 1);

            if (word.Substring(0, 1) == "\"")
                word = word.Substring(1);

            //updates the word frequency--adds the word as a key to the hashtable if not already in the table
            object frequency = wordfreq[word.ToLower()];
            if (frequency == null)
                wordfreq.Add(word.ToLower(), 1);
            else
                wordfreq[word.ToLower()] = (int)frequency + 1;
        }

        /*checks if the occurence of a period at the end of a word means a new sentence under the assumption that 
          a new sentence will begin with a capital letter and the word is not one of a collection of abbreviated titles
          that occurs before a proper nouns, or if it is the last word in the essay*/
        private void checkIfSentenceEnd(int i)
        {
            int j = 1;
            while (!(i + j == word_list.Count))
            {
                if (word_list[i + j].Length == 0)
                    ++j;
                else
                    break;
            }
            if (i + j == word_list.Count)
                ++sentencecount;
            else if (abrv_titles.Contains<string>(word_list[i].ToLower()))
                return;
            else if (char.IsUpper(word_list[i + j].ToCharArray()[0]))
                ++sentencecount;

        }

        //checks each word for punctuation, updates essay punctuation statistics and determines if we are at the end of a sentence
        private void checkPunctuation(string word, int i)
        {
            string lastchar = word.Substring(word.Length - 1);

            if (lastchar == ".")
            {
                checkIfSentenceEnd(i);
            }
            else if ((lastchar == "?") || (lastchar == "!"))
                ++sentencecount;
            else if (lastchar == ",")
                ++commacount;
            else if (lastchar == ";")
                ++semicoloncount;
            else if ((word == "-") || (word == "—"))    //decreases wordcount for any hyphens or dashes that were counted as words
            {   
                --wordcount;
                ++hyphencount;
            }

            if (word.Contains("-"))
                ++hyphencount;

        }
           

    }
}
